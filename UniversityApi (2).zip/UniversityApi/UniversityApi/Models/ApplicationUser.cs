﻿using Microsoft.AspNetCore.Identity;

namespace UniversityApi.Models
{
    public class ApplicationUser : IdentityUser<int>
    {
        public string FullName { get; set; }
        public string Role { get; set; } // "Admin", "Teacher", "Student"
        public string DepartmentName { get; set; } // For teachers/students
        public string? ContactNumber { get; set; }
    }
    public class ApplicationRole : IdentityRole<int> { }
}
