﻿namespace UniversityApi.Models
{
    public class Payment
    {
        public int Id { get; set; }
        public int? CourseId { get; set; }   
        public int StudentId { get; set; }
        public string Semester { get; set; }
        public decimal Amount { get; set; }
        public DateTime PaidAt { get; set; } = DateTime.UtcNow;
    }
}
