﻿namespace UniversityApi.Models
{
    public class Course
    {
        public int Id { get; set; }
        public string CourseName { get; set; }
        public string DepartmentName { get; set; }
        public int Semester { get; set; }
        public decimal Payment { get; set; }
    }
}
