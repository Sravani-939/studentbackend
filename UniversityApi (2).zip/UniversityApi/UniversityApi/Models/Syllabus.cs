﻿namespace UniversityApi.Models
{
    public class Syllabus
    {
        public int Id { get; set; }
        public string DepartmentName { get; set; }
        public int Semester { get; set; }
        public string Description { get; set; }
    }
}
