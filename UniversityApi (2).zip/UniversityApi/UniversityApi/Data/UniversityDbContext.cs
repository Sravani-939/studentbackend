﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using UniversityApi.Models;

namespace UniversityApi.Data;

public class UniversityDbContext : IdentityDbContext<ApplicationUser, ApplicationRole, int>
{
    public UniversityDbContext(DbContextOptions<UniversityDbContext> options) : base(options) { }

    public DbSet<Department> Departments => Set<Department>();
    public DbSet<Course> Courses => Set<Course>();
    public DbSet<Syllabus> Syllabi => Set<Syllabus>();
    public DbSet<Payment> Payments => Set<Payment>();
    public DbSet<Attendance> Attendances => Set<Attendance>();
    public DbSet<Result> Results => Set<Result>();

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        // optional sample seed for departments/courses
        builder.Entity<Department>().HasData(
            new Department { Id = 1, DepartmentName = "Computer Science" },
            new Department { Id = 2, DepartmentName = "Mechanical" }
        );

        builder.Entity<Course>().HasData(
            new Course { Id = 1, CourseName = "Data Structures", DepartmentName = "Computer Science", Semester = 3, Payment = 300M },
            new Course { Id = 2, CourseName = "Algorithms", DepartmentName = "Computer Science", Semester = 4, Payment = 350M }
        );
    }
}