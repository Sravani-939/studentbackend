﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using UniversityApi.Data;
using UniversityApi.Models;

namespace UniversityApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "Student")]
public class StudentController : ControllerBase
{
    private readonly UniversityDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;

    public StudentController(UniversityDbContext db, UserManager<ApplicationUser> userManager)
    {
        _db = db;
        _userManager = userManager;
    }

    private Task<ApplicationUser?> CurrentStudent()
    {
        var username = User.FindFirstValue(ClaimTypes.Name);
        return string.IsNullOrEmpty(username) ? Task.FromResult<ApplicationUser?>(null) : _userManager.FindByNameAsync(username);
    }

    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        var s = await CurrentStudent();
        if (s == null) return Unauthorized();
        return Ok(new { s.Id, s.UserName, s.FullName, s.DepartmentName, s.ContactNumber, s.Email });
    }

    [HttpGet("syllabus")]
    public async Task<IActionResult> Syllabus()
    {
        var s = await CurrentStudent();
        if (s == null) return Unauthorized();
        var sy = await _db.Syllabi.Where(x => x.DepartmentName == s.DepartmentName).OrderBy(x => x.Semester).ToListAsync();
        return Ok(sy);
    }

    [HttpGet("attendance")]
    public async Task<IActionResult> Attendance()
    {
        var s = await CurrentStudent();
        if (s == null) return Unauthorized();

        var data = await (from a in _db.Attendances
                          join c in _db.Courses on a.CourseId equals c.Id
                          where a.StudentId == s.Id
                          orderby a.Date descending
                          select new { a.Id, a.Date, a.IsPresent, c.CourseName, c.Semester }).ToListAsync();

        return Ok(data);
    }

    [HttpGet("results")]
    public async Task<IActionResult> Results()
    {
        var s = await CurrentStudent();
        if (s == null) return Unauthorized();

        var data = await (from r in _db.Results
                          join c in _db.Courses on r.CourseId equals c.Id
                          where r.StudentId == s.Id
                          select new { r.Id, c.CourseName, c.Semester, r.Grade }).ToListAsync();

        return Ok(data);
    }

    [HttpGet("my-payments")]
    public async Task<IActionResult> MyPayments()
    {
        var s = await CurrentStudent();
        if (s == null) return Unauthorized();

        var coursePayments = from p in _db.Payments
                             where p.StudentId == s.Id && p.CourseId != null
                             join c in _db.Courses on p.CourseId equals c.Id
                             select new { p.Id, p.Semester, p.Amount, p.PaidAt, CourseId = p.CourseId, CourseName = c.CourseName };

        var semesterPayments = _db.Payments.Where(p => p.StudentId == s.Id && p.CourseId == null)
                                          .Select(p => new { p.Id, p.Semester, p.Amount, p.PaidAt, CourseId = (int?)null, CourseName = (string?)null });

        var all = await coursePayments.Union(semesterPayments).OrderByDescending(x => x.PaidAt).ToListAsync();
        return Ok(all);
    }

    [HttpGet("my-courses")]
    public async Task<IActionResult> MyCourses()
    {
        var s = await CurrentStudent();
        if (s == null) return Unauthorized();

        var courseIds = await _db.Payments.Where(p => p.StudentId == s.Id && p.CourseId != null).Select(p => p.CourseId!.Value).Distinct().ToListAsync();
        var courses = await _db.Courses.Where(c => courseIds.Contains(c.Id)).ToListAsync();
        return Ok(courses);
    }
}