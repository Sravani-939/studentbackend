﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims;
using UniversityApi.Data;
using UniversityApi.Models;

namespace UniversityApi.Controllers;

[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "Teacher")]
public class TeacherController : ControllerBase
{
    private readonly UniversityDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;

    public TeacherController(UniversityDbContext db, UserManager<ApplicationUser> userManager)
    {
        _db = db;
        _userManager = userManager;
    }

    private Task<ApplicationUser?> CurrentTeacher()
    {
        var username = User.FindFirstValue(ClaimTypes.Name);
        return string.IsNullOrEmpty(username) ? Task.FromResult<ApplicationUser?>(null) : _userManager.FindByNameAsync(username);
    }

    [HttpGet("me")]
    public async Task<IActionResult> Me()
    {
        var t = await CurrentTeacher();
        if (t == null) return Unauthorized();
        return Ok(new { t.Id, t.UserName, t.FullName, t.DepartmentName, t.Email, t.Role });
    }

    [HttpGet("my-students")]
    public async Task<IActionResult> MyStudents()
    {
        var t = await CurrentTeacher();
        if (t == null) return Unauthorized();

        var students = await (from u in _db.Set<ApplicationUser>()
                              join ur in _db.Set<IdentityUserRole<int>>() on u.Id equals ur.UserId
                              join r in _db.Set<ApplicationRole>() on ur.RoleId equals r.Id
                              where r.Name == "Student" && u.DepartmentName == t.DepartmentName
                              select new { u.Id, u.UserName, u.FullName, u.DepartmentName, u.Email }).ToListAsync();

        return Ok(students);
    }

    [HttpGet("my-syllabi")]
    public async Task<IActionResult> MySyllabi()
    {
        var t = await CurrentTeacher();
        if (t == null) return Unauthorized();
        var s = await _db.Syllabi.Where(x => x.DepartmentName == t.DepartmentName).OrderBy(x => x.Semester).ToListAsync();
        return Ok(s);
    }

    [HttpGet("department-courses/{semester:int}")]
    public async Task<IActionResult> DepartmentCourses(int semester)
    {
        var t = await CurrentTeacher();
        if (t == null) return Unauthorized();
        var courses = await _db.Courses.Where(c => c.DepartmentName == t.DepartmentName && c.Semester == semester).ToListAsync();
        return Ok(courses);
    }

    // Post Attendance (only for students + course in same department)
    [HttpPost("attendance")]
    public async Task<IActionResult> PostAttendance([FromBody] Attendance att)
    {
        var t = await CurrentTeacher();
        if (t == null) return Unauthorized();

        var student = await _db.Set<ApplicationUser>().FindAsync(att.StudentId);
        var course = await _db.Courses.FindAsync(att.CourseId);
        if (student == null || course == null) return BadRequest("Invalid student or course");
        if (student.DepartmentName != t.DepartmentName || course.DepartmentName != t.DepartmentName) return Forbid();

        _db.Attendances.Add(att);
        await _db.SaveChangesAsync();
        return Ok(att);
    }

    [HttpPut("attendance/{id:int}")]
    public async Task<IActionResult> UpdateAttendance(int id, [FromBody] Attendance payload)
    {
        var t = await CurrentTeacher();
        if (t == null) return Unauthorized();

        var a = await _db.Attendances.FindAsync(id);
        if (a == null) return NotFound();

        var student = await _db.Set<ApplicationUser>().FindAsync(a.StudentId);
        var course = await _db.Courses.FindAsync(a.CourseId);
        if (student == null || course == null) return BadRequest("Invalid data");
        if (student.DepartmentName != t.DepartmentName || course.DepartmentName != t.DepartmentName) return Forbid();

        a.IsPresent = payload.IsPresent;
        a.Date = payload.Date;
        a.CourseId = payload.CourseId;
        await _db.SaveChangesAsync();
        return Ok(a);
    }

    // Results
    [HttpPost("results")]
    public async Task<IActionResult> PostResult([FromBody] Result r)
    {
        var t = await CurrentTeacher();
        if (t == null) return Unauthorized();

        var student = await _db.Set<ApplicationUser>().FindAsync(r.StudentId);
        var course = await _db.Courses.FindAsync(r.CourseId);
        if (student == null || course == null) return BadRequest("Invalid student or course");
        if (student.DepartmentName != t.DepartmentName || course.DepartmentName != t.DepartmentName) return Forbid();

        _db.Results.Add(r);
        await _db.SaveChangesAsync();
        return Ok(r);
    }

    [HttpPut("results/{id:int}")]
    public async Task<IActionResult> UpdateResult(int id, [FromBody] Result payload)
    {
        var t = await CurrentTeacher();
        if (t == null) return Unauthorized();

        var existing = await _db.Results.FindAsync(id);
        if (existing == null) return NotFound();

        var student = await _db.Set<ApplicationUser>().FindAsync(existing.StudentId);
        var course = await _db.Courses.FindAsync(existing.CourseId);
        if (student == null || course == null) return BadRequest("Invalid data");
        if (student.DepartmentName != t.DepartmentName || course.DepartmentName != t.DepartmentName) return Forbid();

        existing.Grade = payload.Grade;
        await _db.SaveChangesAsync();
        return Ok(existing);
    }
}