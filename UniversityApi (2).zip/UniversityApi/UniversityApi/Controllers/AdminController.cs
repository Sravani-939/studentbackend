﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Linq;
using UniversityApi.Data;
using UniversityApi.Models;
 
namespace UniversityApi.Controllers;
 
[ApiController]
[Route("api/[controller]")]
[Authorize(Roles = "Admin")]
public class AdminController : ControllerBase
{
    private readonly UniversityDbContext _db;
    private readonly UserManager<ApplicationUser> _userManager;
    private readonly RoleManager<ApplicationRole> _roleManager;
 
    public AdminController(UniversityDbContext db, UserManager<ApplicationUser> userManager, RoleManager<ApplicationRole> roleManager)
    {
        _db = db;
        _userManager = userManager;
        _roleManager = roleManager;
    }
 
    public record CreateUserDto(string Username, string Password, string FullName, string DepartmentName,string Role,string ContactNumber);

    // ----- Add Teacher -----
    [HttpPost("add-teacher")]
    public async Task<IActionResult> AddTeacher([FromBody] CreateUserDto dto)
    {
        // Check if username already exists
        if (await _userManager.FindByNameAsync(dto.Username) != null)
            return BadRequest("Username already exists");

        // Create new teacher user
        var user = new ApplicationUser
        {
            UserName = dto.Username,
            Email = $"{dto.Username}@university.com",
            FullName = dto.FullName,
            ContactNumber=dto.ContactNumber,
            Role=dto.Role,
            DepartmentName = dto.DepartmentName
        };

        // Create user with password
        var res = await _userManager.CreateAsync(user, dto.Password);

        if (!res.Succeeded)
            return BadRequest(new { errors = res.Errors.Select(e => e.Description) });

        // Ensure role exists
        if (!await _roleManager.RoleExistsAsync("Teacher"))
            await _roleManager.CreateAsync(new ApplicationRole { Name = "Teacher" });

        // Assign role
        await _userManager.AddToRoleAsync(user, "Teacher");

        return Ok(new { message = "Teacher created successfully", userId = user.Id });
    }


    // ----- Delete Teacher -----
    [HttpDelete("delete-teacher/{id:int}")]
    public async Task<IActionResult> DeleteTeacher(int id)
    {
        var user = await _userManager.FindByIdAsync(id.ToString());
        if (user == null) return NotFound();
        if (!(await _userManager.IsInRoleAsync(user, "Teacher"))) return BadRequest("User is not a teacher");
        await _userManager.DeleteAsync(user);
        return Ok(new { message = "Teacher deleted" });
    }
 
    // ----- Update Teacher -----
    [HttpPut("update-teacher/{id:int}")]
    public async Task<IActionResult> UpdateTeacher(int id, [FromBody] CreateUserDto dto)
    {
        var user = await _userManager.FindByIdAsync(id.ToString());
        if (user == null) return NotFound();
        user.FullName = dto.FullName;
        user.DepartmentName = dto.DepartmentName;
        await _userManager.UpdateAsync(user);
        return Ok(user);
    }
 
    // ----- Add Student -----
    [HttpPost("add-student")]
    public async Task<IActionResult> AddStudent([FromBody] CreateUserDto dto)
    {
        if (await _userManager.FindByNameAsync(dto.Username) != null) return BadRequest("Username exists");
 
        var user = new ApplicationUser
        {
            UserName = dto.Username,
            Email = $"{dto.Username}@example.com",
            FullName = dto.FullName,
            DepartmentName = dto.DepartmentName,
            Role = "Student"
        };
 
        var res = await _userManager.CreateAsync(user, dto.Password);
        if (!res.Succeeded) return BadRequest(res.Errors);
 
        if (!await _roleManager.RoleExistsAsync("Student")) await _roleManager.CreateAsync(new ApplicationRole { Name = "Student" });
        await _userManager.AddToRoleAsync(user, "Student");
 
        return Ok(new { message = "Student created", userId = user.Id });
    }
 
    [HttpDelete("delete-student/{id:int}")]
    public async Task<IActionResult> DeleteStudent(int id)
    {
        var user = await _userManager.FindByIdAsync(id.ToString());
        if (user == null) return NotFound();
        if (!(await _userManager.IsInRoleAsync(user, "Student"))) return BadRequest("User is not a student");
        await _userManager.DeleteAsync(user);
        return Ok(new { message = "Student deleted" });
    }
 
    [HttpPut("update-student/{id:int}")]
    public async Task<IActionResult> UpdateStudent(int id, [FromBody] CreateUserDto dto)
    {
        var user = await _userManager.FindByIdAsync(id.ToString());
        if (user == null) return NotFound();
        user.FullName = dto.FullName;
        user.DepartmentName = dto.DepartmentName;
        await _userManager.UpdateAsync(user);
        return Ok(user);
    }
 
    // ----- Departments -----
    [HttpPost("departments")]
    public async Task<IActionResult> AddDept([FromBody] Department dept)
    {
        _db.Departments.Add(dept);
        await _db.SaveChangesAsync();
        return Ok(dept);
    }
 
    [HttpGet("departments")]
    public async Task<IActionResult> GetDepartments() => Ok(await _db.Departments.ToListAsync());
 
    // ----- Courses -----
    [HttpPost("courses")]
    public async Task<IActionResult> AddCourse([FromBody] Course course)
    {
        _db.Courses.Add(course);
        await _db.SaveChangesAsync();
        return Ok(course);
    }
 
    [HttpGet("semester-courses/{departmentName}/{semester:int}")]
    public async Task<IActionResult> SemesterCourses(string departmentName, int semester)
    {
        var courses = await _db.Courses.Where(c => c.DepartmentName == departmentName && c.Semester == semester).ToListAsync();
        return Ok(courses);
    }
 
    // ----- Syllabus -----
    [HttpPost("syllabus")]
    public async Task<IActionResult> AddSyllabus([FromBody] Syllabus s)
    {
        _db.Syllabi.Add(s);
        await _db.SaveChangesAsync();
        return Ok(s);
    }
 
    // ----- Payments -----
    [HttpPost("post-payment")]
    public async Task<IActionResult> PostPayment([FromBody] Payment p)
    {
        p.PaidAt = DateTime.UtcNow;
        _db.Payments.Add(p);
        await _db.SaveChangesAsync();
        return Ok(p);
    }
 
    [HttpGet("students/{studentId:int}/payments")]
    public async Task<IActionResult> GetStudentPayments(int studentId)
    {
        var coursePayments = from pay in _db.Payments
                             where pay.StudentId == studentId && pay.CourseId != null
                             join c in _db.Courses on pay.CourseId equals c.Id
                             select new { pay.Id, pay.Semester, pay.Amount, pay.PaidAt, CourseId = pay.CourseId, CourseName = c.CourseName };
 
        var semPayments = _db.Payments.Where(p => p.StudentId == studentId && p.CourseId == null)
                                     .Select(p => new { p.Id, p.Semester, p.Amount, p.PaidAt, CourseId = (int?)null, CourseName = (string?)null });
 
        var all = await coursePayments.Union(semPayments).OrderByDescending(x => x.PaidAt).ToListAsync();
        return Ok(all);
    }
}