﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using System.Linq;
using System.Threading.Tasks;
using UniversityApi.Models;
using UniversityApi.Services;

namespace UniversityApi.Controllers
{
    [ApiController]
    [Route("api/[controller]")]
    public class AuthController : ControllerBase
    {
        private readonly UserManager<ApplicationUser> _userManager;
        private readonly RoleManager<ApplicationRole> _roleManager;
        private readonly JwtService _jwt;

        public AuthController(UserManager<ApplicationUser> userManager,
                              RoleManager<ApplicationRole> roleManager,
                              JwtService jwt)
        {
            _userManager = userManager;
            _roleManager = roleManager;
            _jwt = jwt;
        }

        public record LoginDto(string Username, string Password);

        [HttpPost("Login")]
        [AllowAnonymous] // <-- important, otherwise you need a token just to login
        public async Task<IActionResult> Login([FromBody] LoginDto dto)
        {
            if (dto == null || string.IsNullOrWhiteSpace(dto.Username) || string.IsNullOrWhiteSpace(dto.Password))
                return BadRequest("Username and password are required.");

            // Find user by username OR email
            var user = await _userManager.FindByNameAsync(dto.Username)
                       ?? await _userManager.FindByEmailAsync(dto.Username);

            if (user == null)
                return Unauthorized("User not found. Please check your username or email.");

            // Validate password
            var isPasswordValid = await _userManager.CheckPasswordAsync(user, dto.Password);
            if (!isPasswordValid)
                return Unauthorized("Incorrect password.");

            // Get user roles
            var roles = await _userManager.GetRolesAsync(user);

            // Generate JWT token
            var token = _jwt.GenerateToken(user, roles);

            // Return response
            return Ok(new
            {
                token,
                username = user.UserName,
                email = user.Email,
                roles,
                fullName = user.FullName,
                department = user.DepartmentName,
                userId = user.Id
            });
        }
    }
}
